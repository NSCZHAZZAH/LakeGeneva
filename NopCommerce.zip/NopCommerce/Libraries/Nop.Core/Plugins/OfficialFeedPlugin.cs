﻿namespace Nop.Core.Plugins
{
    public class OfficialFeedPlugin
    {
        public string Name { get; set; }
        public string Url { get; set; }
        public string PictureUrl { get; set; }
        public string Category { get; set; }
        public string SupportedVersions { get; set; }
        public string Price { get; set; }
    }
}
