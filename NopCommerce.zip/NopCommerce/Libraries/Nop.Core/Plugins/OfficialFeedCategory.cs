﻿namespace Nop.Core.Plugins
{
    public class OfficialFeedCategory
    {
        public int Id { get; set; }
        public int ParentCategoryId { get; set; }
        public string Name { get; set; }
    }
}
